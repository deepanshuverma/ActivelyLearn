package pageObjects;
/*Description: The class contains all the objects on the Workspace module of activelylearn application
 * Date Created: 29/09/1990
 * Author: Deepanshu Verma
 */

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
//import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Workspace {
	private static WebElement element = null;
	private static WebDriverWait wait = null;
	public static WebElement drpdwn_addContent(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id=\"content\"]/div[4]/div/div[2]/div[2]/div[1]/a"));
		//Select addContent =  new Select(driver.findElement(By.xpath("")));
		//addContent.selectByValue("Import Internet article");
		wait = new WebDriverWait(driver,15);
		wait.until(ExpectedConditions.elementToBeClickable(element));
		
		if(element.isDisplayed())
		{
			return element;
		}
		else
		{
			return null;
		}
	}
	
	public static WebElement txt_url(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//input[@placeholder='URL']"));
		
		wait = new WebDriverWait(driver,15);
		wait.until(ExpectedConditions.elementToBeClickable(element));
		
		if(element.isDisplayed())
		{
			return element;
		}
		else
		{
			return null;
		}
	}
	
	public static WebElement btn_next(WebDriver driver)
	{
		element = driver.findElement(By.cssSelector("a[class='btn ok btn-primary']"));
		wait = new WebDriverWait(driver,15);
		wait.until(ExpectedConditions.elementToBeClickable(element));
		
		if(element.isDisplayed())
		{
			return element;
		}
		else
		{
			return null;
		}
	}
	
	public static WebElement txt_title(WebDriver driver)
	{
		element = driver.findElement(By.xpath("/html/body/div[8]/div/div/div[2]/div/div[2]/input[1]"));
		wait = new WebDriverWait(driver,15);
		wait.until(ExpectedConditions.elementToBeClickable(element));
		
		if(element.isDisplayed())
		{
			return element;
		}
		else
		{
			return null;
		}
	}
	
	public static WebElement txt_author(WebDriver driver)
	{
		element = driver.findElement(By.className("/html/body/div[8]/div/div/div[2]/div/div[2]/input[1]"));
		wait = new WebDriverWait(driver,15);
		wait.until(ExpectedConditions.elementToBeClickable(element));
		
		if(element.isDisplayed())
		{
			return element;
		}
		else
		{
			return null;
		}
	}
	
	public static WebElement drpdwn_gradeLevel(WebDriver driver)
	{
		element = driver.findElement(By.cssSelector("button.btn:nth-child(1)"));
		
		wait = new WebDriverWait(driver,15);
		wait.until(ExpectedConditions.elementToBeClickable(element));
		
		if(element.isDisplayed())
		{
			return element;
		}
		else
		{
			return null;
		}
	}
	
	public static WebElement drpdwn_subject(WebDriver driver)
	{
		element = driver.findElement(By.cssSelector("div.ddlSubjects > button:nth-child(1)"));
		
		//wait = new WebDriverWait(driver,15);
		//wait.until(ExpectedConditions.elementToBeClickable(element));
			return element;
	}
	public static WebElement btn_done(WebDriver driver)
	{
		element = driver.findElement(By.cssSelector("a.btn:nth-child(2)"));
		wait = new WebDriverWait(driver,15);
		wait.until(ExpectedConditions.elementToBeClickable(element));
		
		if(element.isDisplayed())
		{
			return element;
		}
		else
		{
			return null;
		}
	}
	
	public static WebElement img_firstarticle(WebDriver driver)
	{
		element = driver.findElement(By.className("The scaleWidth wide"));
		wait = new WebDriverWait(driver,15);
		wait.until(ExpectedConditions.elementToBeClickable(element));
		
		if(element.isDisplayed())
		{
			return element;
		}
		else
		{
			return null;
		}
	}
	
	public static WebElement btn_Assign(WebDriver driver)
	{
		element = driver.findElement(By.cssSelector("a.btn-box:nth-child(3)"));
		wait = new WebDriverWait(driver,15);
		wait.until(ExpectedConditions.elementToBeClickable(element));
		
		if(element.isDisplayed())
		{
			return element;
		}
		else
		{
			return null;
		}
	}
}
