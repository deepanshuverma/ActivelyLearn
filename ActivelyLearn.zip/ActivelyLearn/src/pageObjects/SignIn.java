package pageObjects;
/*Description: The class contains all the objects on Sign In page of activelylearn application
 * Date Created: 29/09/1990
 * Author: Deepanshu Verma
 */

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class SignIn 
{
	private static WebElement element = null;
	private static WebDriverWait wait = null;
	
	public static WebElement txt_eMail(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id=\"frmSignIn\"]/input"));
		wait = new WebDriverWait(driver,15);
		wait.until(ExpectedConditions.elementToBeClickable(element));
		
		if(element.isDisplayed())
		{
			return element;
		}
		else
		{
			return null;
		}
	}
	
	public static WebElement txt_password(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id=\"frmSignIn\"]/div[1]/input"));
		wait = new WebDriverWait(driver,15);
		wait.until(ExpectedConditions.elementToBeClickable(element));
		
		if(element.isDisplayed())
		{
			return element;
		}
		else
		{
			return null;
		}
	}
	
	public static WebElement btn_SignIn(WebDriver driver)
	{
		element = driver.findElement(By.xpath("//*[@id=\"frmSignIn\"]/a[2]"));
		wait = new WebDriverWait(driver,15);
		wait.until(ExpectedConditions.elementToBeClickable(element));
		
		if(element.isDisplayed())
		{
			return element;
		}
		else
		{
			return null;
		}
	}

}
