package pageObjects;
/*Description: The class contains all the objects on Landing page of activelylearn.com website
 * Date Created: 29/09/1990
 * Author: Deepanshu Verma
 */
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;



public class LandingPage {
	private static WebElement element = null; 
	private static WebDriverWait wait = null;
	
	public static WebElement btn_SignIn(WebDriver driver)
	{
		///html/body/div[1]/nav/a[6]
		element = driver.findElement(By.xpath("/html/body/div[1]/nav/a[6]"));
		
		wait = new WebDriverWait(driver,15);
		wait.until(ExpectedConditions.elementToBeClickable(element));
		
		if(element.isDisplayed())
		{
			return element;
		}
		else
		{
			return null;
		}
		
	}

}
