package utility;

public class Constant 
{
	public static final String URL = "http://www.store.demoqa.com";
	 
    public static final String Username = "testuser_1";

    public static final String Password = "Test@123";

    public static final String Path_TestData = Common.getProjectPath();

    public static final String File_TestData = "TestData.xls";

}
