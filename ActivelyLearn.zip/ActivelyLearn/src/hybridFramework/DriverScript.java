package hybridFramework;
/*Description: The is the Driver Class and contains the test case to be executed
 * Date Created: 29/09/1990
 * Author: Deepanshu Verma
 */
import org.testng.annotations.Test;

import pageObjects.LandingPage;
import pageObjects.SignIn;
import pageObjects.Workspace;
import utility.Common;



import org.testng.annotations.BeforeMethod;


import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;

import org.openqa.selenium.support.ui.WebDriverWait;

import org.testng.annotations.AfterMethod;

public class DriverScript {
	
	public WebDriver driver;
	
  // This method represents the test scenarioof adding the articel from internet and and assigning it to an existing class
  @Test (priority =1)
  public void addAndAssignArticle() throws Exception
  {
	  
	  /*The Below steps Logs in to the teacher to the application 
	   */
	  LandingPage.btn_SignIn(driver).click();
	  driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	  SignIn.txt_eMail(driver).sendKeys("test@testautomation.com");
	  SignIn.txt_password(driver).sendKeys("test1234");
	  SignIn.btn_SignIn(driver).click();
	  Common.getScreenshot(driver, "SignIn.png");
	  /* After Logging in the article will be added from the Internet 	  
	   */
	  
	  driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	  Workspace.drpdwn_addContent(driver).click();
	  
	  driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	  
	  String vArticleURL = "http://www.thehindu.com/features/kids/Gandhiji-%E2%80%94-an-inspiration/article12542442.ece";
	  driver.findElement(By.xpath("//*[@id=\"content\"]/div[4]/div/div[2]/div[2]/div[1]/ul/li[2]/a")).click();
	  driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	  
	  Workspace.txt_url(driver).sendKeys(vArticleURL);
	  Workspace.btn_next(driver).click();
	  driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	  Workspace.drpdwn_gradeLevel(driver).click();
	  driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	  driver.findElement(By.cssSelector("ul.dropdown-menu:nth-child(1) > li:nth-child(2) > a:nth-child(1)")).click();
		
	  Workspace.drpdwn_subject(driver).click();
	  driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	  WebElement ee =  driver.findElement(By.cssSelector("div.ddlSubjects > div:nth-child(2) > ul:nth-child(1) > li:nth-child(3) > a:nth-child(1)"));
	  JavascriptExecutor executor = (JavascriptExecutor)driver;
	  executor.executeScript("arguments[0].click();", ee);
		
	  Workspace.btn_done(driver).click();
	  
		
	  /* Once the article is added then script waits and verifies whether the correct article is getting reflected or not
	   */
		
	  WebDriverWait waitArticle = new WebDriverWait(driver,50);
	  waitArticle.until(ExpectedConditions.elementToBeClickable(driver.findElement(By.cssSelector("img[alt='Gandhiji - an inspiration']"))));
	  Common.getScreenshot(driver, "AddArticel.png");
	  /*After making sure the article has been added correctly,the script will assign it to a class "testing"
	   */
	  
	  Workspace.btn_Assign(driver).click();
	  String vclassName = driver.findElement(By.cssSelector(".checklist > li:nth-child(1) > div:nth-child(2)")).getText();
	  if (vclassName.equals("testing"))
	  {
		  driver.findElement(By.cssSelector("div.checkbox:nth-child(1) > label:nth-child(2)")).click();
		  driver.findElement(By.cssSelector("a.btn:nth-child(2)")).click();
		  driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		  Common.getScreenshot(driver, "AssignToClass.png");
		  driver.findElement(By.cssSelector("a.btn")).click();
	  }
		
		/*
		 * Test Case Ended - Article Gandhiji - an inspiration has been successfully assigned to the class testing
		 */
		
  }
  
  
  @BeforeMethod
  public void beforeMethod() 
  {
	  //DOMConfigurator.configure("log4j.xml");
	  
		//Log.startTestCase("AL_001");
		System.setProperty("webdriver.chrome.driver",Common.getProjectPath()+"\\Selenium_Driver\\chromedriver.exe");
		driver = new ChromeDriver();
		String vURL = "https://www.activelylearn.com";
		driver.get(vURL);
		driver.manage().window().maximize();
		
  }

  @AfterMethod
  public void afterMethod() {
	  driver.quit();
  }
  

}
